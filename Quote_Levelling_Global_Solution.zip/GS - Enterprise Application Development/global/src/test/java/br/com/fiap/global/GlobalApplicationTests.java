package br.com.fiap.global;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalApplicationTests {

	@Test
	void contextLoads() {
	}

}
