package br.com.fiap.global.validation;

public record RestValidationError(String field, String message) {
}
